# Thought Logic Intelligence Demo

Live demo of account intelligence system for management consulting.

## Features
- Organizational mapping (C-suite + VP/Director level)
- Intent data signals (active buyer detection)
- Warm intro path identification
- Real executive data (Delta, McKesson, Home Depot)

Auto-deploys to Netlify on push.
